function op1(){

    var n1 = 10;
    var n2 = 5;
    var resul;

    if(resul > 10){
        console.log("el resultado es mayor que 10")
    }else{
        console.log("el resultado es menor que 10")
    }

}

function op2(){
    var n3 = 10;

    for(i = 0; i<n3 ; i++ ){
        console.log(i);
    }

}
function op3(){
    cont = 0;

    while(cont < 5){
        cont++;
        console.log(cont);
    }
}
